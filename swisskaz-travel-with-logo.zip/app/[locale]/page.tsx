export default function Home() {
  return (
    <main style={{ textAlign: 'center', marginTop: '50px' }}>
      <img src="/logo.png" alt="SwissKaz Travel Logo" width="250" />
      <h1>Welcome to SwissKaz Travel</h1>
      <p>DISCOVER THE UNDISCOVERED</p>
    </main>
  );
}
/** @type {import('next').NextConfig} */
const nextConfig = {
  i18n: {
    locales: ['en', 'de', 'ru'],
    defaultLocale: 'en',
  },
};

module.exports = nextConfig;